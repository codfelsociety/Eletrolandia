﻿namespace BLL.Data
{
    public class Produtos
    {
        public class ProdutosSimples
        {
            public string Nome { get; set; }
            public decimal Custo { get; set; }
            public decimal Preco { get; set; }
        }
    }
}

﻿using System.Data;
using DAO;

namespace BLL
{
    public class Fornecedor
    {
        private static string SQL;
        public static DataView Load()
        {
            SQL = "SELECT COD_FORNECEDOR, NOME FROM fornecedor";
            DataView dv = ClasseConexao.RetornarDataTable(SQL).DefaultView;

            return dv;
        }
        public void Cadastrar()
        {
            SQL = "";
        }
        public void Alterar()
        {

        }
        public void Apagar()
        {

        }
    }
}

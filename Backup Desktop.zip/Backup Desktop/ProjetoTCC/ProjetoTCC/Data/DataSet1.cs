﻿namespace ProjetoTCC.Data
{


    partial class DataSet1
    {
        partial class DataTable1DataTable
        {
            public string Nome { get; set; }
            public decimal Custo { get; set; }
            public decimal Preco { get; set; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoTCC.Data
{
    public class Produtos
    {
        public class ProdutosSimples
        {
            public string Nome { get; set; }
            public decimal Custo { get; set; }
            public decimal Preco { get; set; }
        }
    }
}
